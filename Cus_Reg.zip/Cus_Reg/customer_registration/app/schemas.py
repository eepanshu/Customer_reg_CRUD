from pydantic import BaseModel, EmailStr
from typing import Annotated
from pydantic.types import constr

class CustomerBase(BaseModel):
    name: str  # ✅ Add this line
    phone: Annotated[str, constr(min_length=10, max_length=15)]
    email: EmailStr
    company: str = None
    designation: str = None

class CustomerCreate(CustomerBase):
    pass

class CustomerUpdate(CustomerBase):
    pass

class CustomerOut(CustomerBase):
    id: int

    class Config:
        from_attributes = True  # updated from orm_mode
