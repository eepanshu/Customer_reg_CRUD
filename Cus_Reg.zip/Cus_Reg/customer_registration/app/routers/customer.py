from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .. import crud, schemas, database

router = APIRouter(prefix="/customers", tags=["Customers"])

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/", response_model=schemas.CustomerOut)
def create(customer: schemas.CustomerCreate, db: Session = Depends(get_db)):
    return crud.create_customer(db, customer)

@router.get("/", response_model=list[schemas.CustomerOut])
def read_all(db: Session = Depends(get_db)):
    return crud.get_customers(db)

@router.get("/{customer_id}", response_model=schemas.CustomerOut)
def read(customer_id: int, db: Session = Depends(get_db)):
    db_customer = crud.get_customer(db, customer_id)
    if db_customer is None:
        raise HTTPException(status_code=404, detail="Customer not found")
    return db_customer

@router.put("/{customer_id}", response_model=schemas.CustomerOut)
def update(customer_id: int, customer: schemas.CustomerUpdate, db: Session = Depends(get_db)):
    return crud.update_customer(db, customer_id, customer)

@router.delete("/{customer_id}")
def delete(customer_id: int, db: Session = Depends(get_db)):
    return crud.delete_customer(db, customer_id)
