document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("customerForm");

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const customerData = {
            name: document.getElementById('name').value,
            phone: document.getElementById('phone').value,
            email: document.getElementById('email').value,
            company: document.getElementById('company').value || null,
            designation: document.getElementById('designation').value || null
        };

        try {
            const response = await fetch('/customers/', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(customerData)
            });

            if (response.ok) {
                alert('Customer registered successfully!');
                form.reset();
            } else {
                const error = await response.json();
                alert('Error: ' + (error.detail || 'Failed to submit.'));
            }
        } catch (err) {
            alert('Error: ' + err.message);
        }
    });
});
