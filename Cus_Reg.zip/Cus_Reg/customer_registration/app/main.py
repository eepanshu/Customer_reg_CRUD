from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from app.routers import customer  # Ensure import is correct for your folder structure

app = FastAPI()

# Include customer router
app.include_router(customer.router)

# Jinja2 template config
templates = Jinja2Templates(directory="app/templates")

# Static files (optional, for custom CSS or JS)
app.mount("/static", StaticFiles(directory="app/static"), name="static")

# Route for frontend form
@app.get("/")
async def get_form(request: Request):
    return templates.TemplateResponse("form.html", {"request": request})

# Activate the virtual environment
# venv\Scripts\activate

# To run the app, use the command:
# uvicorn app.main:app --reload
# This will start the server at http://127.0.0.1:8000/
# and you can access the form at http://127.0.0.1:8000/customers/
# For Swagger: http://127.0.0.1:8000/docs#/